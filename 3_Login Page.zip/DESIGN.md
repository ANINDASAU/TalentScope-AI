---
name: Elite Performance Tech
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#00687a'
  on-secondary: '#ffffff'
  secondary-container: '#57dffe'
  on-secondary-container: '#006172'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002109'
  on-tertiary-container: '#009844'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-hero:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.08em
  mono-data:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system is built on the intersection of elite athletic performance and cutting-edge artificial intelligence. It evokes a sense of precision, speed, and authoritative insight. Drawing inspiration from high-end sports apparel and premium hardware interfaces, the aesthetic is **Minimalist** with functional **Glassmorphism**. 

The UI should feel lightweight yet grounded, using heavy whitespace to allow data visualizations to breathe. Transitions must be fluid and "smart"—elements should slide and fade with a refined ease-in-out motion that mimics the grace of a professional athlete. The overall atmosphere is professional, data-centric, and undeniably modern.

## Colors
This design system utilizes a high-contrast palette to ensure technical legibility. The **Primary Deep Slate** provides the structural anchor, used for text and heavy navigation elements. **Cyan** acts as the high-energy "AI accent," highlighting data insights, active states, and interactive triggers.

The background uses a slightly cool-toned off-white to reduce eye strain during long analysis sessions. Success, Warning, and Danger colors are saturated and vibrant, intended for immediate cognitive recognition of performance metrics and system alerts.

## Typography
The typography strategy pairs the technical, mono-influenced precision of **Geist** for headings and data labels with the universal readability of **Inter** for body content. 

Hero headings use tight tracking and bold weights to command attention, while data labels utilize uppercase styling to create a clear visual distinction from narrative text. On mobile, display sizes scale down aggressively to maintain focus on visual data without sacrificing the "bold" brand character.

## Layout & Spacing
The system follows a strict **8px grid** to ensure mathematical consistency across components. For desktop, we utilize a **12-column fixed grid** (max-width 1440px) to maintain a professional, organized dashboard feel. Mobile layouts shift to a **fluid single-column model** with 16px side margins.

Content density should be kept moderate; use the `lg` and `xl` spacing tokens to create "breathing room" between major data modules. Gutters are kept wide (24px) to emphasize the separation of distinct AI insights.

## Elevation & Depth
Depth is expressed through **Tonal Layers** and **Glassmorphism** rather than traditional heavy shadows. 
- **Surface 0 (Background):** Solid `#F8FAFC`.
- **Surface 1 (Cards):** Solid White with a subtle 1px border (`#0F172A` at 5% opacity).
- **Surface 2 (Overlays):** Glassmorphic panels with `backdrop-filter: blur(12px)` and 80% opacity white fill.

Shadows, when used, are "Ambient Shadows"—extremely soft, using the Primary Slate color at 4-6% opacity with a high blur radius (20px+) to suggest a gentle lift off the page.

## Shapes
The shape language is **Rounded**, balancing the technical nature of AI with the organic movement of human athletes. 
- Standard components (buttons, inputs) use a **0.5rem (8px)** radius.
- Large containers and dashboard cards use a **1rem (16px)** radius.
- Circular gauges and progress indicators remain perfectly round to emphasize the "Target/Focus" motif common in sports analytics.

## Components

### Buttons
- **Primary:** Solid Deep Slate with White text. High contrast, sharp focus.
- **Action:** Solid Cyan with Deep Slate text for high-priority AI triggers.
- **Ghost:** Transparent background with 1px Cyan border.

### Sleek Cards
Cards should be the primary container for all data. Use white backgrounds with subtle 1px borders. Header areas within cards should use the `label-caps` typography to categorize data types (e.g., "BIOMETRICS", "ACCELERATION").

### Data Visualizations & Gauges
Circular gauges are used for "Score" metrics. The stroke should be thick (8px-12px) with a rounded cap. Use Cyan for the "Active" progress and a very light Slate (10% opacity) for the "Track."

### AI Skeleton Overlays
In video or image components, use "Skeleton-pose" motifs. These consist of 2px Cyan lines connecting small (4px) white dots at joints. Use a 50% opacity for the lines to ensure the underlying athlete remains visible.

### Input Fields
Inputs are minimalist: a bottom-only border or a very light gray stroke. On focus, the border transitions to Cyan with a subtle 4px Cyan outer glow (blur).

### Skeleton Loaders
Use a subtle shimmer animation (left-to-right) across light gray blocks to indicate loading states, maintaining the flow of the UI even during data fetching.